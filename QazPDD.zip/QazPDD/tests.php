<?php
require_once 'config/database.php';require_once 'includes/functions.php';require_login();
$uid=(int)current_user()['id'];$sub=active_subscription($pdo,$uid)!==null;
$cnt=[];foreach($pdo->query("SELECT ticket_no,COUNT(*) c FROM questions WHERE is_published=1 GROUP BY ticket_no") as $r)$cnt[(int)$r['ticket_no']]=(int)$r['c'];
$best=[];$q=$pdo->prepare("SELECT ticket_no,MAX(correct_answers) b,COUNT(*) n FROM test_attempts WHERE user_id=? AND ticket_no IS NOT NULL GROUP BY ticket_no");$q->execute([$uid]);foreach($q as $r)$best[(int)$r['ticket_no']]=['b'=>(int)$r['b'],'n'=>(int)$r['n']];
$pageTitle='Тесттер — QazPDD';require 'includes/header.php';?>
<section class="section"><h1 class="page-title">Емтихан блоктары</h1>
<p class="muted">Барлығы <?=BLOCK_COUNT?> блок, әр блокта <?=BLOCK_QUESTIONS?> сұрақ. Өту үшін кемінде <strong><?=PASS_MARK?></strong> дұрыс жауап керек. 1-блок тегін және шексіз қайталауға болады; 2–<?=BLOCK_COUNT?> блоктар төлем жасағаннан кейін ашылады.<?php if(!$sub):?> <a href="packages.php">Тарифтерді көру</a><?php endif;?></p>
<div class="ticket-grid blocks"><?php for($n=1;$n<=BLOCK_COUNT;$n++):$open=$n===1||$sub;$k=$cnt[$n]??0;$b=$best[$n]??null;$cls=$n===1?'free':($open?'':'locked');if($b)$cls.=$b['b']>=PASS_MARK?' passed':' failed';?>
<a class="ticket <?=$cls?>" href="<?=e(base_url())?><?=$open?'test.php?block='.$n:'packages.php'?>"><strong><?=$n?>-блок</strong><small><?php if(!$open):?>ақылы 🔒<?php elseif($b):?>үздік: <?=$b['b']?>/<?=BLOCK_QUESTIONS?><?php else:?><?=$k?> сұрақ<?php endif;?></small></a>
<?php endfor;?></div></section><?php require 'includes/footer.php';?>
