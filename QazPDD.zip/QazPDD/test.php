<?php
require_once 'config/database.php';require_once 'includes/functions.php';require_login();verify_csrf();
$userId=(int)current_user()['id'];

function load_block(PDO $pdo,int $block):array{
  $q=$pdo->prepare("SELECT id,question_text,image_path,video_path,explanation,correct_option_id FROM questions WHERE is_published=1 AND ticket_no=? ORDER BY id LIMIT ".BLOCK_QUESTIONS);
  $q->execute([$block]);$qs=$q->fetchAll();
  $o=$pdo->prepare("SELECT id,option_text FROM question_options WHERE question_id=? ORDER BY sort_order,id");
  foreach($qs as &$x){$o->execute([$x['id']]);$x['options']=$o->fetchAll();}unset($x);
  return $qs;
}
function render_media(array $q):string{
  $h='';
  if($q['image_path'])$h.='<img class="qmedia" src="'.e(media_url($q['image_path'])).'" alt="Сұрақ суреті">';
  if($q['video_path'])$h.='<video class="qmedia" controls preload="metadata" playsinline src="'.e(media_url($q['video_path'])).'"></video>';
  return $h;
}

if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['finish_test'])){
  $block=(int)($_POST['block']??0);
  if(!can_access_block($pdo,$userId,$block)){$_SESSION['flash']='Бұл блок ақылы. Ашу үшін тариф сатып алыңыз.';header('Location: packages.php');exit;}
  $qs=load_block($pdo,$block);$answers=$_POST['answers']??[];
  if(!$qs){$_SESSION['flash']='Сұрақтар табылмады.';header('Location: tests.php');exit;}
  $marks=0;$review=[];
  foreach($qs as $q){
    $valid=array_map(fn($o)=>(int)$o['id'],$q['options']);
    $sel=isset($answers[$q['id']])?(int)$answers[$q['id']]:null;if($sel!==null&&!in_array($sel,$valid,true))$sel=null;
    $ok=$sel!==null&&$sel===(int)$q['correct_option_id'];if($ok)$marks++;
    $review[]=['text'=>$q['question_text'],'image'=>$q['image_path'],'video'=>$q['video_path'],'options'=>$q['options'],'selected'=>$sel,'correct'=>(int)$q['correct_option_id'],'ok'=>$ok,'explanation'=>$q['explanation'],'qid'=>(int)$q['id']];
  }
  $total=count($qs);$percent=$total?round($marks/$total*100,2):0;
  $pdo->beginTransaction();
  try{
    $pdo->prepare("INSERT INTO test_attempts(user_id,ticket_no,total_questions,correct_answers,score_percent) VALUES(?,?,?,?,?)")->execute([$userId,$block,$total,$marks,$percent]);
    $aid=(int)$pdo->lastInsertId();$sv=$pdo->prepare("INSERT INTO test_answers(attempt_id,question_id,selected_option_id,is_correct) VALUES(?,?,?,?)");
    foreach($review as $r)$sv->execute([$aid,$r['qid'],$r['selected'],$r['ok']?1:0]);
    $pdo->commit();
  }catch(Throwable $e){$pdo->rollBack();throw $e;}
  $_SESSION['last_result']=['block'=>$block,'total'=>$total,'correct'=>$marks,'percent'=>(int)round($percent),'passed'=>$marks>=PASS_MARK,'review'=>$review];
  header('Location: results.php');exit;
}

$block=filter_input(INPUT_GET,'block',FILTER_VALIDATE_INT)?:1;
if(!can_access_block($pdo,$userId,$block)){$_SESSION['flash']=$block>BLOCK_COUNT||$block<1?'Блок табылмады.':'Бұл блок ақылы. Ашу үшін тариф сатып алыңыз.';header('Location: '.($block>=1&&$block<=BLOCK_COUNT?'packages.php':'tests.php'));exit;}
$questions=load_block($pdo,$block);
$pageTitle=$block.'-блок — QazPDD';require 'includes/header.php';?>
<section class="section"><h1 class="page-title"><?=$block?>-блок</h1>
<?php if(!$questions):?><div class="card"><h3>Бұл блокқа сұрақтар әлі енгізілмеген</h3><a class="btn" href="tests.php">Блоктарға оралу</a></div>
<?php else:$n=count($questions);?>
<form method="post" id="exam" data-total="<?=$n?>"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="finish_test" value="1"><input type="hidden" name="block" value="<?=$block?>">
<div class="exam"><div>
<?php foreach($questions as $i=>$q):?><article class="card qpane<?=$i===0?' active':''?>" data-i="<?=$i?>"><span class="badge">Сұрақ <?=$i+1?> / <?=$n?></span><h3><?=e($q['question_text'])?></h3><?=render_media($q)?>
<?php foreach($q['options'] as $o):?><label class="option"><input type="radio" name="answers[<?=(int)$q['id']?>]" value="<?=(int)$o['id']?>"> <?=e($o['option_text'])?></label><?php endforeach;?></article><?php endforeach;?>
<div class="q-controls"><button type="button" class="btn secondary" id="prev">← Алдыңғы</button><button type="button" class="btn" id="next">Келесі →</button></div></div>
<aside class="exam-nav"><div class="timer" id="timer">00:00</div><p class="muted">Жауап берілді: <strong id="done">0</strong> / <?=$n?>. Өту шегі: <?=PASS_MARK?>.</p><div class="nav-grid" id="navgrid"><?php for($i=0;$i<$n;$i++):?><button type="button" data-go="<?=$i?>"><?=$i+1?></button><?php endfor;?></div><button class="btn" type="submit" id="finish" style="width:100%">Тестті аяқтау</button></aside></div></form>
<script>
(function(){
const panes=[...document.querySelectorAll('.qpane')],btns=[...document.querySelectorAll('#navgrid button')],total=panes.length;let cur=0;
function show(i){cur=Math.max(0,Math.min(total-1,i));panes.forEach((p,k)=>{p.classList.toggle('active',k===cur);p.querySelectorAll('video').forEach(v=>{if(k!==cur)v.pause()})});btns.forEach((b,k)=>b.classList.toggle('current',k===cur));document.getElementById('prev').disabled=cur===0;document.getElementById('next').disabled=cur===total-1;window.scrollTo({top:0,behavior:'smooth'})}
function refresh(){let d=0;panes.forEach((p,k)=>{const a=!!p.querySelector('input:checked');if(a)d++;btns[k].classList.toggle('answered',a)});document.getElementById('done').textContent=d;return d}
btns.forEach(b=>b.addEventListener('click',()=>show(+b.dataset.go)));
document.getElementById('prev').onclick=()=>show(cur-1);document.getElementById('next').onclick=()=>show(cur+1);
document.addEventListener('keydown',e=>{if(e.target.tagName==='TEXTAREA')return;if(e.key==='ArrowRight')show(cur+1);if(e.key==='ArrowLeft')show(cur-1)});
document.getElementById('exam').addEventListener('change',refresh);
document.getElementById('exam').addEventListener('submit',e=>{const d=refresh();if(d<total&&!confirm('Жауап берілмеген сұрақтар: '+(total-d)+'. Бәрібір аяқтайсыз ба?')){e.preventDefault();return}const f=document.getElementById('finish');setTimeout(()=>{f.disabled=true;f.textContent='Өңделуде…'},0)});
const t0=Date.now(),tm=document.getElementById('timer');setInterval(()=>{const s=Math.floor((Date.now()-t0)/1000);tm.textContent=String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')},1000);
show(0);refresh();
})();
</script>
<?php endif;?></section><?php require 'includes/footer.php';?>
