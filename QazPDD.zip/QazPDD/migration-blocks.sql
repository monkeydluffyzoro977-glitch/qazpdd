-- Бар базаны жаңарту үшін phpMyAdmin-де pdd_platform таңдап орындаңыз (бір рет)
ALTER TABLE questions ADD COLUMN video_path VARCHAR(500) NULL AFTER image_path;
ALTER TABLE test_attempts ADD COLUMN ticket_no SMALLINT UNSIGNED NULL AFTER category_id;
-- Блок 1 тегін, қалғаны ақылы:
UPDATE questions SET is_free = (ticket_no = 1);
INSERT INTO road_signs(name,description,image_path,sort_order) VALUES
('«STOP» қозғалысты тоқтату','Міндетті түрде толық тоқтап, қиылыстағы басымдығы бар көліктерге жол беру керек.','uploads/signs/stop.svg',1),
('Жол беріңіз','Басты жолдағы көліктерге жол беру міндетті.','uploads/signs/give-way.svg',2),
('Кіруге тыйым салынған','Бұл бағытпен барлық көліктің кіруіне тыйым.','uploads/signs/no-entry.svg',3),
('Басты жол','Қиылыстарда басымдық беретін жол.','uploads/signs/main-road.svg',4),
('Жылдамдықты 40 км/сағ-пен шектеу','Белгі әрекеті аймағында 40 км/сағ-тан жоғары жүруге болмайды.','uploads/signs/speed-40.svg',5),
('Жылдамдықты 60 км/сағ-пен шектеу','Белгі әрекеті аймағында 60 км/сағ-тан жоғары жүруге болмайды.','uploads/signs/speed-60.svg',6),
('Жылдамдықты 90 км/сағ-пен шектеу','Белгі әрекеті аймағында 90 км/сағ-тан жоғары жүруге болмайды.','uploads/signs/speed-90.svg',7),
('Басып озуға тыйым салынған','Бұл белгі әрекеті аймағында барлық көлікті (баяу жүретін көліктерден басқа) басып озуға тыйым салынады.','uploads/signs/no-overtaking.svg',8),
('Тұрақка тыйым салынған','Белгі әрекеті аймағында көлікті қоюға болмайды.','uploads/signs/no-parking.svg',9),
('Жаяу жүргіншілер','Жолда жаяу жүргіншілер болуы мүмкін, абай болыңыз.','uploads/signs/pedestrian.svg',10),
('Айналмалы қозғалыс','Айналма жолмен көрсетілген бағытта жүріңіз.','uploads/signs/roundabout.svg',11),
('Жаяу жүргіншілер өткелі','Өткелге жақындағанда жылдамдықты азайтып, жүргіншілерге жол беріңіз.','uploads/signs/crossing.svg',12),
('Басқа қауіп','Жолдың алдыңғы бөлігінде қауіпті жағдай болуы мүмкін.','uploads/signs/danger.svg',13);
