<?php require_once 'config/database.php';require_once 'includes/functions.php';require_login();$r=$_SESSION['last_result']??null;$pageTitle='Тест нәтижесі — QazPDD';require 'includes/header.php';?>
<section class="section"><?php if(!$r):?><div class="card"><h1>Нәтиже табылмады</h1><a class="btn" href="tests.php">Блоктарға оралу</a></div>
<?php else:$wrong=$r['total']-$r['correct'];?>
<div class="card"><h1 class="page-title"><?=(int)$r['block']?>-блок нәтижесі</h1>
<p class="verdict <?=$r['passed']?'pass':'fail'?>"><?=$r['passed']?'✔ Тест тапсырылды':'✘ Тест тапсырылмады'?> — <?=PASS_MARK?> дұрыс жауап керек еді</p>
<div class="stats"><div class="stat"><strong><?=(int)$r['correct']?> / <?=(int)$r['total']?></strong><span class="muted">Дұрыс жауап (<?=(int)$r['percent']?>%)</span></div><div class="stat"><strong><?=$wrong?></strong><span class="muted">Қате немесе жауапсыз</span></div></div>
<div class="actions"><a class="btn" href="test.php?block=<?=(int)$r['block']?>">Қайта тапсыру</a><a class="btn secondary" href="tests.php">Барлық блоктар</a><a class="btn secondary" href="dashboard.php">Жеке кабинет</a></div></div>
<section class="section"><h2>Барлық сұрақтардың талдауы</h2>
<?php foreach($r['review'] as $i=>$it):?><article class="card question <?=$it['ok']?'review-ok':'review-bad'?>"><span class="badge"><?=$i+1?>-сұрақ — <?=$it['ok']?'дұрыс':($it['selected']===null?'жауап берілмеді':'қате')?></span><h3><?=e($it['text'])?></h3>
<?php if($it['image']):?><img class="qmedia" src="<?=e(media_url($it['image']))?>" alt=""><?php endif;?><?php if($it['video']):?><video class="qmedia" controls preload="none" src="<?=e(media_url($it['video']))?>"></video><?php endif;?>
<?php foreach($it['options'] as $o):$oid=(int)$o['id'];$c=$oid===$it['correct']?'opt-correct':($oid===$it['selected']?'opt-wrong':'');?><p class="<?=$c?>"><?=$oid===$it['correct']?'✔ ':($oid===$it['selected']?'✘ ':'• ')?><?=e($o['option_text'])?><?=$oid===$it['selected']?' (сенің жауабың)':''?></p><?php endforeach;?>
<?php if($it['explanation']):?><p class="muted">💡 <?=e($it['explanation'])?></p><?php endif;?></article><?php endforeach;?></section>
<?php endif;?></section><?php require 'includes/footer.php';?>
