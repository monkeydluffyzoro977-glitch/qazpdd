<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Сұрау мерзімі жарамсыз. Бетті жаңартыңыз.'); } }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) { header('Location: '.base_url().'login.php'); exit; } }
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function require_admin(): void { require_login(); if (!is_admin()) { http_response_code(403); exit('Бұл бөлім тек әкімшіге арналған.'); } }
function active_subscription(PDO $pdo, int $userId): ?array {
    $q=$pdo->prepare("SELECT s.*, p.name AS package_name FROM subscriptions s JOIN packages p ON p.id=s.package_id WHERE s.user_id=? AND s.status='active' AND s.ends_at > NOW() ORDER BY s.ends_at DESC LIMIT 1");
    $q->execute([$userId]); return $q->fetch() ?: null;
}
function can_access_question(PDO $pdo, int $userId, int $questionId): bool {
    $q=$pdo->prepare("SELECT is_free FROM questions WHERE id=? AND is_published=1"); $q->execute([$questionId]); $row=$q->fetch();
    if (!$row) return false;
    if ((int)$row['is_free'] === 1) return true;
    return active_subscription($pdo,$userId) !== null;
}

function base_url(): string {
    $root=rtrim(str_replace('\\','/',$_SERVER['DOCUMENT_ROOT']??''),'/');$dir=str_replace('\\','/',dirname(__DIR__));
    $b=($root!==''&&strncasecmp($dir,$root,strlen($root))===0)?substr($dir,strlen($root)):'';
    return rtrim($b,'/').'/';
}
function price_html(array $p): string {
    $old=(float)$p['price'];$d=(float)$p['discount_percent'];$f=fn($v)=>number_format($v,0,'.',' ').' ₸';
    if($d>0){$new=round($old*(1-$d/100));return '<div class="price-wrap"><s class="old-price">'.$f($old).'</s><span class="price">'.$f($new).'</span></div>';}
    return '<div class="price">'.$f($old).'</div>';
}

const BLOCK_COUNT = 20;
const BLOCK_QUESTIONS = 40;
const PASS_MARK = 32;
function can_access_block(PDO $pdo, int $userId, int $block): bool {
    if ($block < 1 || $block > BLOCK_COUNT) return false;
    return $block === 1 || active_subscription($pdo, $userId) !== null;
}
function media_url(?string $path): string {
    if (!$path) return '';
    if (preg_match('#^https?://#i', $path)) return $path;
    return base_url() . ltrim($path, '/');
}
