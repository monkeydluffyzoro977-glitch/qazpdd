<?php
require_once 'config/database.php';require_once 'includes/functions.php';require_login();verify_csrf();
$uid=(int)current_user()['id'];$error='';$done=null;$pkg=null;
$id=(int)($_POST['package_id']??0);
if($id){$q=$pdo->prepare("SELECT * FROM packages WHERE id=? AND is_active=1");$q->execute([$id]);$pkg=$q->fetch()?:null;}
if(!$pkg&&$_SERVER['REQUEST_METHOD']==='POST'){$_SESSION['flash']='Пакет табылмады.';header('Location: packages.php');exit;}
if($pkg){
  $amount=round((float)$pkg['price']*(1-(float)$pkg['discount_percent']/100),2);
  if(isset($_POST['pay'])){
    $card=preg_replace('/\D/','',$_POST['card_number']??'');
    $holder=trim($_POST['holder']??'');
    $exp=trim($_POST['expiry']??'');
    $cvv=preg_replace('/\D/','',$_POST['cvv']??'');
    $okExp=false;
    if(preg_match('/^(0[1-9]|1[0-2])\s*\/\s*(\d{2})$/',$exp,$m)){$okExp=((int)('20'.$m[2])*100+(int)$m[1])>=(int)date('Ym');}
    if(strlen($card)!==16)$error='Карта нөмірі 16 саннан тұруы керек.';
    elseif($holder==='')$error='Карта иесінің атын енгізіңіз.';
    elseif(!$okExp)$error='Жарамдылық мерзімін AA/ЖЖ форматында енгізіңіз (мерзімі өтпеген болуы керек).';
    elseif(strlen($cvv)!==3)$error='CVV 3 саннан тұруы керек.';
    else{
      $pdo->beginTransaction();
      try{
        $ref='DEMO-'.strtoupper(bin2hex(random_bytes(5)));
        $pdo->prepare("INSERT INTO orders(user_id,package_id,amount,status,reference_code) VALUES(?,?,?,'paid_demo',?)")->execute([$uid,$id,$amount,$ref]);
        $order=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO payments(order_id,method,status,is_demo,amount,provider_reference) VALUES(?,'demo','success',1,?,?)")->execute([$order,$amount,'**** '.substr($card,-4)]);
        $pdo->prepare("INSERT INTO subscriptions(user_id,package_id,starts_at,ends_at,status,order_id) VALUES(?,?,NOW(),DATE_ADD(NOW(), INTERVAL ? DAY),'active',?)")->execute([$uid,$id,(int)$pkg['duration_days'],$order]);
        $pdo->commit();
        $done=['ref'=>$ref,'last4'=>substr($card,-4)];
      }catch(Throwable $e){$pdo->rollBack();$error='Төлемді сақтау кезінде қате болды. Қайта көріңіз.';}
    }
  }
}
$pageTitle='Төлем — QazPDD';require 'includes/header.php';
if($done):?>
<section class="form-card receipt"><h1>Төлем жасалды</h1><p class="success">Төлем сәтті өтті. «<?=e($pkg['name'])?>» пакеті іске қосылды.</p>
<div class="pay-summary"><div><span class="muted">Сумма</span><strong><?=number_format($amount,0,'.',' ')?> ₸</strong></div><div><span class="muted">Карта</span><strong>**** <?=e($done['last4'])?></strong></div><div><span class="muted">Тапсырыс нөмірі</span><strong><?=e($done['ref'])?></strong></div><div><span class="muted">Қолжетімділік</span><strong><?=(int)$pkg['duration_days']?> күн</strong></div></div>
<a class="btn" href="tests.php">Тест тапсыруды бастау</a></section>
<?php elseif($pkg):?>
<section class="form-card"><h1>Төлем</h1>
<p class="notice">Бұл оқу жобасы: нақты ақша алынбайды, карта деректері сақталмайды (тек соңғы 4 цифр). Нақты картаңызды енгізбеңіз.</p>
<?php if($error):?><p class="error"><?=e($error)?></p><?php endif;?>
<div class="pay-summary"><div><span class="muted">Пакет</span><strong><?=e($pkg['name'])?></strong></div><div><span class="muted">Мерзімі</span><strong><?=(int)$pkg['duration_days']?> күн</strong></div></div>
<form method="post" data-disable-submit autocomplete="off"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="package_id" value="<?=$id?>"><input type="hidden" name="pay" value="1">
<label for="amount">Төлем сомасы</label><input id="amount" value="<?=number_format($amount,0,'.',' ')?> ₸" readonly>
<label for="card">Карта нөмірі</label><input id="card" name="card_number" data-card inputmode="numeric" autocomplete="cc-number" placeholder="0000 0000 0000 0000" maxlength="19" required value="<?=e($_POST['card_number']??'')?>">
<label for="holder">Карта иесі</label><input id="holder" name="holder" autocomplete="cc-name" placeholder="AIDAR NURLANOV" required value="<?=e($_POST['holder']??'')?>">
<div class="card-row"><div><label for="exp">Жарамдылық мерзімі</label><input id="exp" name="expiry" data-expiry inputmode="numeric" autocomplete="cc-exp" placeholder="AA/ЖЖ" maxlength="5" required value="<?=e($_POST['expiry']??'')?>"></div><div><label for="cvv">CVV</label><input id="cvv" name="cvv" type="password" inputmode="numeric" autocomplete="cc-csc" placeholder="•••" maxlength="3" required></div></div>
<button class="btn" type="submit">Төлеу — <?=number_format($amount,0,'.',' ')?> ₸</button></form></section>
<?php else:?>
<section class="form-card"><h1>Төлем</h1><p class="notice">Алдымен тарифтер бетінен пакет таңдаңыз.</p><a class="btn" href="packages.php">Тарифтерге өту</a></section>
<?php endif;require 'includes/footer.php';
